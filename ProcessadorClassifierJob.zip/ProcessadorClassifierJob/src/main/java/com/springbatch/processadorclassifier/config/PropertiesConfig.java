package com.springbatch.processadorclassifier.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.FileSystemResource;

/**
 * 
 * @author dfs_c
 * Classe utilizada para externalizar o arquivo de propriedades
 *
 */
@Configuration
public class PropertiesConfig {
	
	@Bean
	public PropertySourcesPlaceholderConfigurer config() {
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		configurer.setLocation(new FileSystemResource("/temp/config/application.properties"));
		return configurer;
	}
}
